let nombre="Bradigson";
let matricula = "2018-6114";

function view(){
    alert("Hello There! My name is "+" "+nombre +" "+ "and my registration is"+" "+ matricula);
}